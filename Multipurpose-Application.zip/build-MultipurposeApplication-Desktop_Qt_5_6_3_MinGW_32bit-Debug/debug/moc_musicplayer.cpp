/****************************************************************************
** Meta object code from reading C++ file 'musicplayer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MultipurposeApplication/musicplayer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'musicplayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MusicPlayer_t {
    QByteArrayData data[24];
    char stringdata0[389];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MusicPlayer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MusicPlayer_t qt_meta_stringdata_MusicPlayer = {
    {
QT_MOC_LITERAL(0, 0, 11), // "MusicPlayer"
QT_MOC_LITERAL(1, 12, 18), // "on_btnOpen_clicked"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 18), // "on_btnPlay_clicked"
QT_MOC_LITERAL(4, 51, 19), // "on_btnPause_clicked"
QT_MOC_LITERAL(5, 71, 18), // "on_btnStop_clicked"
QT_MOC_LITERAL(6, 90, 14), // "on_add_clicked"
QT_MOC_LITERAL(7, 105, 17), // "on_remove_clicked"
QT_MOC_LITERAL(8, 123, 15), // "on_save_clicked"
QT_MOC_LITERAL(9, 139, 17), // "on_repeat_clicked"
QT_MOC_LITERAL(10, 157, 18), // "on_forward_clicked"
QT_MOC_LITERAL(11, 176, 15), // "on_play_clicked"
QT_MOC_LITERAL(12, 192, 15), // "on_back_clicked"
QT_MOC_LITERAL(13, 208, 18), // "on_shuffle_clicked"
QT_MOC_LITERAL(14, 227, 15), // "on_mute_clicked"
QT_MOC_LITERAL(15, 243, 27), // "on_listWidget_doubleClicked"
QT_MOC_LITERAL(16, 271, 5), // "index"
QT_MOC_LITERAL(17, 277, 25), // "on_volumeBar_valueChanged"
QT_MOC_LITERAL(18, 303, 5), // "value"
QT_MOC_LITERAL(19, 309, 22), // "on_seekBar_sliderMoved"
QT_MOC_LITERAL(20, 332, 8), // "position"
QT_MOC_LITERAL(21, 341, 24), // "on_searchBar_textChanged"
QT_MOC_LITERAL(22, 366, 4), // "arg1"
QT_MOC_LITERAL(23, 371, 17) // "on_play_3_clicked"

    },
    "MusicPlayer\0on_btnOpen_clicked\0\0"
    "on_btnPlay_clicked\0on_btnPause_clicked\0"
    "on_btnStop_clicked\0on_add_clicked\0"
    "on_remove_clicked\0on_save_clicked\0"
    "on_repeat_clicked\0on_forward_clicked\0"
    "on_play_clicked\0on_back_clicked\0"
    "on_shuffle_clicked\0on_mute_clicked\0"
    "on_listWidget_doubleClicked\0index\0"
    "on_volumeBar_valueChanged\0value\0"
    "on_seekBar_sliderMoved\0position\0"
    "on_searchBar_textChanged\0arg1\0"
    "on_play_3_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MusicPlayer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    0,  108,    2, 0x08 /* Private */,
       7,    0,  109,    2, 0x08 /* Private */,
       8,    0,  110,    2, 0x08 /* Private */,
       9,    0,  111,    2, 0x08 /* Private */,
      10,    0,  112,    2, 0x08 /* Private */,
      11,    0,  113,    2, 0x08 /* Private */,
      12,    0,  114,    2, 0x08 /* Private */,
      13,    0,  115,    2, 0x08 /* Private */,
      14,    0,  116,    2, 0x08 /* Private */,
      15,    1,  117,    2, 0x08 /* Private */,
      17,    1,  120,    2, 0x08 /* Private */,
      19,    1,  123,    2, 0x08 /* Private */,
      21,    1,  126,    2, 0x08 /* Private */,
      23,    0,  129,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   16,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void,

       0        // eod
};

void MusicPlayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MusicPlayer *_t = static_cast<MusicPlayer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {


        case 4: _t->on_add_clicked(); break;
        case 5: _t->on_remove_clicked(); break;

        case 7: _t->on_repeat_clicked(); break;
        case 8: _t->on_forward_clicked(); break;
        case 9: _t->on_play_clicked(); break;
        case 10: _t->on_back_clicked(); break;
        case 11: _t->on_shuffle_clicked(); break;
        case 12: _t->on_mute_clicked(); break;
        case 13: _t->on_listWidget_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 14: _t->on_volumeBar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_seekBar_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_searchBar_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;

        default: ;
        }
    }
}

const QMetaObject MusicPlayer::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MusicPlayer.data,
      qt_meta_data_MusicPlayer,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MusicPlayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MusicPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MusicPlayer.stringdata0))
        return static_cast<void*>(const_cast< MusicPlayer*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MusicPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
